import { Component, OnInit } from '@angular/core';
import { Router, Params, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-department-list',
  template: `<h2>Department Details</h2>
                <ul class ="items">
                  <li  (click)= "onSelect(department)" [class.selected]="isSelected(department)" *ngFor= "let department of departmentList">
                  <span class="badge"> {{department.id}}</span> {{department.name}}</li>
                </ul>`,
})
export class DepartmentListComponent implements OnInit {
  public selectedId ;
  constructor(private router: Router, private route: ActivatedRoute) { }
  departmentList = [
    {'name': 'Angular', 'id': 1},
    {'name': 'Node', 'id': 2},
    {'name': 'MongoDB', 'id': 3},
    {'name': 'React', 'id': 4},
    {'name': 'Bootstrap', 'id': 5}
];
ngOnInit() {
  this.route.params.subscribe((params: Params) => {
    const id = params['id'];
    this.selectedId = id;
  });
}
onSelect(department) {
  this.router.navigate(['/departments', department.id ]);
}

isSelected(department) {
  return department.id === this.selectedId ;
}

}
