import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<H1>Routing Application</H1><br/>
               <nav>
                <a routerLink="/departments" routerlinkActive="active" >Department</a>
                <a routerLink="/employees" routerlinkActive="active" >Employees</a>
               </nav> <br/><br/>
               <router-outlet></router-outlet>
               `,
  styleUrls: [ './app.component.css' ],
})
export class AppComponent  {
  name = 'Angular';
}
