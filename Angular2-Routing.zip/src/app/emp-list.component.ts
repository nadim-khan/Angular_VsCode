import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-list',
  template:`<h2>Employee Details</h2>              
                <ul *ngFor= "let employee of employeeList">
                  <li>{{employee.id}}. {{employee.name}} - {{employee.gender}}
                </ul>`,
  styles: []
})
export class EmployeeListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
employeeList=[
    {"name": "Nadeem", "id": 1, "gender":"Male"},
    {"name": "Deepshikha", "id": 2, "gender":"FeMale"},
    {"name": "Shyam", "id": 3, "gender":"Male"},
    {"name": "Arpita", "id": 4, "gender":"FeMale"},
    {"name": "Pratibha", "id": 5, "gender":"FeMale"}
]
}